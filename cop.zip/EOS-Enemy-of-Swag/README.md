# EOS — Enemy of Swag

A dark cinematic React storefront with an Express API, Shopify Storefront API integration, protected content admin, PostgreSQL-backed settings, and a Render Blueprint.

## Included
- The supplied EOS emblem appears only in the homepage hero. No visible “666” text or numeral motif.
- Responsive dark editorial storefront, optional muted looping video, animated atmospheric fallback, scroll reveals, animated ticker, responsive navigation, product filters, size variants, quick-add, sliding cart, quantity controls and Shopify checkout handoff.
- Live product/price/availability data from Shopify; prices are not hardcoded into the storefront.
- `/admin` protected by an environment-configured password and signed HttpOnly session cookie.
- Admin controls for announcement, hero copy/image/video, editorial section, motion intensity, accent color and footer statement.
- PostgreSQL persistence for settings, plus Render Blueprint configuration.

## Local development
Requires Node.js 20+ and PostgreSQL for persistent admin settings.

1. Copy `.env.example` to `.env`.
2. Set `ADMIN_PASSWORD` to a strong unique password and `SESSION_SECRET` to a random secret with at least 32 characters.
3. Configure Shopify Storefront API values and database URL.
4. Run `npm install` then `npm run dev`.

Vite runs the frontend on port 5173 and proxies API calls to Express on port 3001. Production: `npm run build && npm start`.

## Shopify setup
Create a Storefront API access token in Shopify and grant the scopes required to read products and create carts. Set:
- `SHOPIFY_STORE_DOMAIN` to the `*.myshopify.com` hostname without `https://`
- `SHOPIFY_STOREFRONT_ACCESS_TOKEN` to the token, kept server-side
- `SHOPIFY_API_VERSION` to a supported pinned version (default `2025-10`)

The storefront reads products, variant prices and availability from Shopify and creates a Shopify cart for checkout. Product editing, inventory, orders, discounts, shipping/taxes and payment methods remain managed in Shopify Admin. Shopify checkout/payment setup must be completed before live orders. If Shopify is not configured, the website shows an empty-store state rather than inventing products or prices.

## Admin
Visit `/admin`. Set `ADMIN_PASSWORD` and `SESSION_SECRET` in the server environment. The password is never shipped in frontend code. Admin content settings persist in PostgreSQL; don't rely on in-memory settings in production. The dashboard does not replace Shopify Admin for product, price or inventory edits.

## Render deployment
This repository contains `render.yaml`, configured for a Node web service and PostgreSQL in Singapore as a reasonable starting region for a Nigeria-based audience. Render plan availability and free-resource limits can change; review current details before applying.

1. Push the project to a GitHub, GitLab or Bitbucket repository.
2. In Render, select **New + → Blueprint**, connect that repository and apply `render.yaml`.
3. In the web service environment settings, set `ADMIN_PASSWORD`, `SHOPIFY_STORE_DOMAIN`, `SHOPIFY_STOREFRONT_ACCESS_TOKEN`, and `APP_ORIGIN` (your final HTTPS Render URL or custom domain). Optionally set `HERO_VIDEO_URL` to a public HTTPS MP4/WebM URL.
4. Wait for deployment. Verify `/api/health`, `/admin`, product loading, cart and Shopify checkout.
5. Configure your custom domain and test shipping, taxes and payment methods before taking live orders.

The included database plan is intended for initial preview. Check current Render retention/expiry, resource and pricing limits before relying on it for production. Upgrade resources as required.

## Security / launch checklist
- Never commit `.env` or expose Shopify tokens in browser code.
- Use HTTPS in production; admin cookies are marked Secure in production.
- Rotate secrets immediately if they are ever exposed.
- Admin currently uses one environment-configured administrator password. Teams needing roles, audit logs or password reset should add a full identity provider.
- Add rate limiting and monitoring before a high-traffic launch.
- Test on iOS/Android, test reduced-motion settings, and run Shopify's test payment flow before accepting real payments.
