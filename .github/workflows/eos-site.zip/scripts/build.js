import { access, stat } from "node:fs/promises";
import path from "node:path";

const required = [
  "public/index.html",
  "public/styles.css",
  "src/app.js",
  "src/catalog.js",
  "server.js",
  "public/assets/campaign-noise.png"
];
for (const file of required) {
  await access(path.resolve(file));
  const info = await stat(path.resolve(file));
  if (!info.isFile()) throw new Error(`${file} is not a file`);
}
console.log(`EOS production preflight passed: ${required.length} required files found.`);
console.log("Static assets are served directly from /public; no bundler step is required.");
