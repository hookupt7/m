# ENEMY OF SWAG (EOS) — storefront

A custom editorial horror-fashion storefront starter. It uses a deliberately narrow visual system rather than a generic template: ink-black surfaces, bone typography, blood-red accents, oversized editorial type, asymmetrical campaign composition, and restrained motion.

## Requirements
- Node.js 20+
- npm
- Git

## Run locally
```bash
npm install
cp .env.example .env
npm run dev
```
Open http://localhost:3000.

## Exact Render commands
**Build command**
```bash
npm install && npm run build
```
**Start command**
```bash
npm start
```
`render.yaml` contains the same settings.

## Included
- Responsive home, collection, product detail, cart drawer, editorial manifesto, and contact views
- Search and category filtering
- Variant selection, cart persistence, quantity controls, and checkout guard
- Accessible menu, keyboard focus states, reduced-motion support, form feedback
- Express server with Helmet security headers, compression, request logging, health endpoint, and explicit API routes
- Locally stored original abstract campaign artwork and product textures
- SEO metadata, Open Graph tags, sitemap, robots file, and product JSON-LD
- Shopify integration configuration placeholders (no secrets included)

## Commerce honesty
This project does not pretend to take payments. The cart is functional locally, but checkout requires a real Shopify storefront configuration and a store with checkout/payment settings enabled. Until those are configured, the checkout action explains the setup requirement instead of faking an order. Products/prices in `src/catalog.js` are clearly labelled demo data until connected to Shopify.

## Configure Shopify before selling
1. Add `SHOPIFY_STORE_DOMAIN` and a Storefront API token to Render environment variables. Never commit tokens.
2. Implement/verify the Storefront API cart and checkout flow against the store's current API version.
3. Publish products, verify sizes/variants and inventory, enable a payment provider, and test a real end-to-end order in Shopify.
4. Set `SITE_ORIGIN` to the final public domain.
5. Replace all sample campaign art and placeholder contact details with approved brand assets and business information.

## Quality checks before launch
- `npm run check`
- Test mobile navigation and every product variant on an actual phone
- Test keyboard-only navigation and reduced motion
- Verify links, image loading, error/empty states, checkout, and forms
- Run Lighthouse and target Core Web Vitals: LCP ≤ 2.5s, INP < 200ms, CLS < 0.1
- Confirm policies, shipping, returns, privacy, and contact details before accepting orders

## Folder structure
```text
eos-enemy-of-swag/
├── public/
│   ├── assets/       # campaign artwork and texture assets
│   ├── products/     # locally stored product artwork
│   ├── favicon.svg
│   ├── robots.txt
│   ├── sitemap.xml
│   └── styles.css
├── server/
│   └── security.js
├── scripts/
│   └── build.js
├── src/
│   ├── app.js
│   ├── catalog.js
│   └── views.js
├── .env.example
├── .gitignore
├── package.json
├── render.yaml
├── server.js
└── README.md
```
