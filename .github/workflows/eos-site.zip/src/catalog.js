export const catalog = [
  {
    id: "kill-or-be-killed",
    name: "Kill or Be Killed Tee",
    category: "T-shirts",
    price: 35000,
    label: "01 / CORE UNIFORM",
    description: "Heavyweight streetwear cut. A stark, graphic statement built for repeat wear, not a single photograph.",
    sizes: ["S", "M", "L", "XL", "2XL"],
    image: "/products/kill-or-be-killed.png",
    status: "Preview"
  },
  {
    id: "some-love-be-cursed",
    name: "Some Love Be Cursed Tee",
    category: "T-shirts",
    price: 50000,
    label: "02 / AFTER HOURS",
    description: "A darker romantic graphic, printed as a worn-in relic rather than a clean, disposable trend.",
    sizes: ["S", "M", "L", "XL", "2XL"],
    image: "/products/some-love-be-cursed.png",
    status: "Preview"
  },
  {
    id: "no-saints",
    name: "No Saints Long Sleeve",
    category: "Long sleeves",
    price: 42000,
    label: "03 / CONCEPT",
    description: "An editorial concept piece. Final fabric, fit, and availability must be confirmed before release.",
    sizes: ["S", "M", "L", "XL", "2XL"],
    image: "/products/no-saints.png",
    status: "Concept"
  }
];

export const formatPrice = amount => new Intl.NumberFormat("en-NG", {
  style: "currency", currency: "NGN", maximumFractionDigits: 0
}).format(amount);
