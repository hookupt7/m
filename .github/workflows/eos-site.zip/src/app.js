import { catalog, formatPrice } from "./catalog.js";
import { icon } from "./views.js";

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const state = { filter: "All", sort: "featured", cart: loadCart(), selectedProduct: null, selectedSize: null };

function loadCart() {
  try { return JSON.parse(localStorage.getItem("eos-cart") || "[]"); } catch { return []; }
}
function saveCart() {
  localStorage.setItem("eos-cart", JSON.stringify(state.cart));
  renderCart();
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function showToast(message) {
  const toast = $("[data-toast]");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function visibleProducts() {
  let items = catalog.filter(p => state.filter === "All" || p.category === state.filter);
  if (state.sort === "low") items = items.slice().sort((a,b) => a.price-b.price);
  if (state.sort === "high") items = items.slice().sort((a,b) => b.price-a.price);
  return items;
}
function renderProducts() {
  const grid = $("[data-product-grid]");
  grid.innerHTML = visibleProducts().map((p, i) => `
    <article class="product-card">
      <div class="product-image-wrap">
        <img class="product-image" src="${p.image}" alt="${escapeHTML(p.name)} campaign artwork" loading="${i === 0 ? "eager" : "lazy"}" width="900" height="1125">
        <span class="product-tag">${escapeHTML(p.label)}</span>
        <button class="product-quick" data-product-open="${p.id}" aria-label="View ${escapeHTML(p.name)}">VIEW PIECE <span>↗</span></button>
      </div>
      <div class="product-meta"><div><h3 class="product-name">${escapeHTML(p.name)}</h3><span class="product-code">${escapeHTML(p.category.toUpperCase())} / ${escapeHTML(p.status.toUpperCase())}</span></div><span class="product-price">${formatPrice(p.price)}</span></div>
    </article>`).join("");
  $$("[data-product-open]", grid).forEach(btn => btn.addEventListener("click", () => openProduct(btn.dataset.productOpen)));
}
function openProduct(id) {
  const p = catalog.find(item => item.id === id);
  if (!p) return;
  state.selectedProduct = p;
  state.selectedSize = null;
  const modal = document.createElement("div");
  modal.className = "product-modal open";
  modal.dataset.productModal = "";
  modal.innerHTML = `<div class="product-modal-inner" role="dialog" aria-modal="true" aria-labelledby="modal-title">
    <button class="modal-close" data-modal-close aria-label="Close product details">CLOSE ×</button>
    <img src="${p.image}" alt="${escapeHTML(p.name)} artwork" width="900" height="1125">
    <div class="product-modal-copy"><p class="eyebrow">${escapeHTML(p.label)}</p><h2 id="modal-title">${escapeHTML(p.name)}</h2><div class="modal-price">${formatPrice(p.price)}</div><p>${escapeHTML(p.description)}</p><p><strong>Release status:</strong> ${escapeHTML(p.status)}. Confirm availability before purchase.</p><span class="size-label">SELECT SIZE</span><div class="size-options">${p.sizes.map(size => `<button type="button" data-size="${size}" aria-pressed="false">${size}</button>`).join("")}</div><button class="button modal-add" data-add-to-cart>ADD TO BAG <span>↗</span></button></div>
  </div>`;
  document.body.append(modal);
  document.body.classList.add("locked");
  modal.querySelector("[data-modal-close]").addEventListener("click", closeProduct);
  modal.addEventListener("click", e => { if (e.target === modal) closeProduct(); });
  $$("[data-size]", modal).forEach(btn => btn.addEventListener("click", () => {
    state.selectedSize = btn.dataset.size;
    $$("[data-size]", modal).forEach(other => { other.classList.toggle("selected", other === btn); other.setAttribute("aria-pressed", String(other === btn)); });
  }));
  modal.querySelector("[data-add-to-cart]").addEventListener("click", () => {
    if (!state.selectedSize) return showToast("Choose a size before adding this piece.");
    const key = `${p.id}:${state.selectedSize}`;
    const existing = state.cart.find(item => item.key === key);
    if (existing) existing.quantity += 1;
    else state.cart.push({ key, id: p.id, size: state.selectedSize, quantity: 1 });
    saveCart();
    closeProduct();
    openCart();
    showToast("Added to your bag.");
  });
  modal.querySelector("[data-modal-close]").focus();
}
function closeProduct() {
  $("[data-product-modal]")?.remove();
  document.body.classList.remove("locked");
}
function cartDetails() {
  return state.cart.map(item => {
    const p = catalog.find(product => product.id === item.id);
    return p ? { ...item, product: p, lineTotal: p.price * item.quantity } : null;
  }).filter(Boolean);
}
function renderCart() {
  const details = cartDetails();
  const count = details.reduce((n, item) => n + item.quantity, 0);
  $$("[data-cart-count]").forEach(el => el.textContent = count);
  const itemsEl = $("[data-cart-items]");
  itemsEl.innerHTML = details.length ? details.map(item => `
    <article class="cart-line">
      <img src="${item.product.image}" alt="" width="92" height="115">
      <div><h3>${escapeHTML(item.product.name)}</h3><p>SIZE ${escapeHTML(item.size)} · ${formatPrice(item.product.price)}</p><div class="quantity-control"><button data-qty="${item.key}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${item.quantity}</span><button data-qty="${item.key}" data-delta="1" aria-label="Increase quantity">+</button></div><button class="remove-item" data-remove="${item.key}">REMOVE</button></div>
      <strong>${formatPrice(item.lineTotal)}</strong>
    </article>`).join("") : `<div class="cart-empty"><p>Your bag is empty.</p><a class="text-link" href="#collection" data-cart-shop>RETURN TO THE COLLECTION ↗</a></div>`;
  $("[data-cart-total]").textContent = formatPrice(details.reduce((n,item) => n + item.lineTotal, 0));
  $$("[data-qty]").forEach(btn => btn.addEventListener("click", () => {
    const item = state.cart.find(i => i.key === btn.dataset.qty);
    if (!item) return;
    item.quantity += Number(btn.dataset.delta);
    if (item.quantity < 1) state.cart = state.cart.filter(i => i.key !== item.key);
    saveCart();
  }));
  $$("[data-remove]").forEach(btn => btn.addEventListener("click", () => {
    state.cart = state.cart.filter(i => i.key !== btn.dataset.remove); saveCart();
  }));
  $("[data-cart-shop]")?.addEventListener("click", closeCart);
}
function openCart() {
  $("[data-cart-drawer]").classList.add("open");
  $("[data-cart-backdrop]").classList.add("open");
  $("[data-cart-drawer]").setAttribute("aria-hidden", "false");
  document.body.classList.add("locked");
  $("[data-cart-close]").focus();
}
function closeCart() {
  $("[data-cart-drawer]").classList.remove("open");
  $("[data-cart-backdrop]").classList.remove("open");
  $("[data-cart-drawer]").setAttribute("aria-hidden", "true");
  document.body.classList.remove("locked");
}
function openMenu() {
  $("[data-menu-panel]").classList.add("open");
  $("[data-menu-panel]").setAttribute("aria-hidden", "false");
  document.body.classList.add("locked");
}
function closeMenu() {
  $("[data-menu-panel]").classList.remove("open");
  $("[data-menu-panel]").setAttribute("aria-hidden", "true");
  document.body.classList.remove("locked");
}
function searchProducts(query) {
  const result = $("[data-search-results]");
  const q = query.trim().toLowerCase();
  const matches = catalog.filter(p => !q || `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q));
  result.innerHTML = matches.length ? matches.map(p => `<a class="search-result" href="#collection" data-search-product="${p.id}"><span>${escapeHTML(p.name)}</span><span>${formatPrice(p.price)} ↗</span></a>`).join("") : `<p class="form-status">Nothing found. Try a different term.</p>`;
  $$("[data-search-product]", result).forEach(a => a.addEventListener("click", () => {
    $("[data-search]").classList.remove("open");
    document.body.classList.remove("locked");
    openProduct(a.dataset.searchProduct);
  }));
}
function bind() {
  $$("[data-filter]").forEach(btn => btn.addEventListener("click", () => {
    state.filter = btn.dataset.filter;
    $$("[data-filter]").forEach(b => b.classList.toggle("active", b === btn));
    renderProducts();
  }));
  $("[data-sort]").addEventListener("change", e => { state.sort = e.target.value; renderProducts(); });
  $("[data-cart-open]").addEventListener("click", openCart);
  $("[data-cart-close]").addEventListener("click", closeCart);
  $("[data-cart-backdrop]").addEventListener("click", closeCart);
  $("[data-menu-open]").addEventListener("click", openMenu);
  $("[data-menu-close]").addEventListener("click", closeMenu);
  $$("[data-menu-link]").forEach(a => a.addEventListener("click", closeMenu));
  $("[data-search-open]").addEventListener("click", () => {
    $("[data-search]").classList.add("open"); $("[data-search]").setAttribute("aria-hidden","false");
    document.body.classList.add("locked"); $("#site-search").focus(); searchProducts("");
  });
  $("[data-search-close]").addEventListener("click", () => {
    $("[data-search]").classList.remove("open"); $("[data-search]").setAttribute("aria-hidden","true"); document.body.classList.remove("locked");
  });
  $("#site-search").addEventListener("input", e => searchProducts(e.target.value));
  $("[data-checkout]").addEventListener("click", async () => {
    try {
      const response = await fetch("/api/config");
      const config = await response.json();
      if (!config.commerceConfigured) {
        $("[data-checkout-note]").textContent = "Live checkout is not connected. Configure Shopify Storefront API and payment settings before selling.";
        showToast("Checkout is not configured yet. No order has been placed.");
        return;
      }
      // Never claim checkout is complete without a real Storefront API cart URL.
      showToast("Shopify credentials are present; a verified Storefront API cart flow must be connected before checkout.");
    } catch {
      showToast("Unable to verify checkout setup. No order has been placed.");
    }
  });
  $("[data-newsletter]").addEventListener("submit", e => {
    e.preventDefault();
    const input = $("#newsletter-email");
    if (!input.checkValidity()) return input.reportValidity();
    $("[data-newsletter-status]").textContent = "Your email is valid, but the mailing-list provider must be connected before subscriptions can be saved.";
    showToast("Mailing-list delivery is not configured yet.");
    input.value = "";
  });
  $$("a[href^='#']").forEach(a => a.addEventListener("click", e => {
    const target = document.querySelector(a.getAttribute("href"));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" }); }
  }));
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { closeProduct(); closeCart(); closeMenu(); $("[data-search]").classList.remove("open"); document.body.classList.remove("locked"); }
  });
}
renderProducts();
renderCart();
bind();
$("[data-year]").textContent = new Date().getFullYear();
