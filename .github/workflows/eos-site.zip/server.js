import express from "express";
import compression from "compression";
import helmet from "helmet";
import morgan from "morgan";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { applySecurity } from "./server/security.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);

app.disable("x-powered-by");
app.use(compression());
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      fontSrc: ["'self'", "data:"],
      connectSrc: ["'self'", "https://*.myshopify.com"],
      mediaSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === "production" ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false,
  referrerPolicy: { policy: "strict-origin-when-cross-origin" }
}));
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));
app.use(express.json({ limit: "32kb" }));
app.use(applySecurity);
app.use(express.static(path.join(__dirname, "public"), {
  maxAge: process.env.NODE_ENV === "production" ? "7d" : 0,
  etag: true,
  extensions: ["html"]
}));

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "eos-storefront", timestamp: new Date().toISOString() });
});

app.get("/api/config", (_req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({
    commerceConfigured: Boolean(process.env.SHOPIFY_STORE_DOMAIN && process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN),
    currency: "NGN",
    brand: "Enemy of Swag"
  });
});

app.post("/api/contact", (req, res) => {
  const { name, email, message } = req.body || {};
  if (typeof name !== "string" || name.trim().length < 2 ||
      typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      typeof message !== "string" || message.trim().length < 10) {
    return res.status(400).json({ error: "Enter a name, valid email, and message of at least 10 characters." });
  }
  // Intentionally does not pretend to email or store the message. Connect a real mail provider before launch.
  return res.status(202).json({ message: "Form validated. Contact delivery must be configured by the store owner before launch." });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, "0.0.0.0", () => {
  console.log(`EOS storefront listening on port ${port}`);
});
